import setuptools


setuptools.setup(
    name="Pagintion",
    version="v1.0",
    author="ZhangJian",
    author_email="15332962628@163.com",
    description="分页组件",
    long_description="",
    packages=setuptools.find_packages(),

    # classifiers=[
    #
    # ],
    install_requires=[
        'django',
    ],
    python_requires='>=3',


)